def main():
    print('Hi, I recommend importing the module like this:',
          'from bool_quetion import true_false', sep='\n')
