#!/usr/bin/env python3
from sys import argv, exit

if len(argv) < 2:
    print()
    exit (1)

command = argv[0].split('/')[-1]
command = 'capitalize' if command == 'capital' else command
argv_str = ' '.join(argv[1:])

if len(argv) == 2 and argv[1] in ('-h', '--help'):
    show = 'hello world'
    if command == 'lower':
        show = show.upper()
    print (command, show)
    print ('\033[1mResult:\033[0m', getattr(show, command)())
    print (f' -h, --help\t\tdisplay this help and exit')
    print (f' -v, --version\t\toutput version information and exit')
elif len(argv) == 2 and argv[1] in ('-v', '--version'):
    with open(
            '/usr/share/flipcase/version.txt',
            'r',
            encoding='utf-8'
            ) as file:
        version = file.readline().strip()
    print (f'{command} (flipcase) {version}')
else:
    print (getattr(argv_str, command)() + '\033[0m')
