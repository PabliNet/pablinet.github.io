from pathlib import Path
from PIL import Image


def create_image(src, dst, cols, rows, gap, bg=None):
    with Image.open(src) as img:

        canvas_width = (
            img.width * cols
            + gap * (cols + 1)
        )

        canvas_height = (
            img.height * rows
            + gap * (rows + 1)
        )

        if bg is None:
            bg = '#ffffff'
            if Path(dst).suffix.lower() == '.png':
                if img.mode == 'RGB':
                    img = img.convert('RGBA')
                bg = (0, 0, 0, 0)

        canvas = Image.new(img.mode, (canvas_width, canvas_height), bg)

        for row in range(rows):
            for col in range(cols):

                pos_x = gap + col * (img.width + gap)
                pos_y = gap + row * (img.height + gap)

                canvas.paste(img, (pos_x, pos_y))

        canvas.save(dst)
