from pathlib import Path
from PIL import Image


def create_image(src, dst, cols, rows, gap, bg=None, dpi=(300, 300)):
    with Image.open(src) as img:

        canvas_width = (
            img.width * cols
            + gap * (cols + 1)
        )

        canvas_height = (
            img.height * rows
            + gap * (rows + 1)
        )

        if bg is None:
            bg = '#ffffff'
            if Path(dst).suffix.lower() == '.png':
                if img.mode == 'RGB':
                    img = img.convert('RGBA')
                bg = (0, 0, 0, 0)

        canvas = Image.new(img.mode, (canvas_width, canvas_height), bg)

        for row in range(rows):
            for col in range(cols):

                pos_x = gap + col * (img.width + gap)
                pos_y = gap + row * (img.height + gap)

                canvas.paste(img, (pos_x, pos_y))

        save_kwargs = {}
        if (dpi and isinstance(dpi, (tuple, list)) and len(dpi) == 2 and
                all(isinstance(x, (int, float)) and x > 0 for x in dpi)):
            save_kwargs['dpi'] = dpi
        elif isinstance(dpi, (int, float)) and dpi > 0:
            save_kwargs['dpi'] = (dpi, dpi)
        elif dpi is None or isinstance(dpi, str) and len(dpi) == 0:
            pass
        else:
            raise ValueError(
                f"Invalid dpi: {dpi!r}. Expected None, '' (empty string, "
                f'equivalent to None), a positive int/float, or a tuple/list '
                f'of two positive numbers.'
            )

        canvas.save(dst, **save_kwargs)
